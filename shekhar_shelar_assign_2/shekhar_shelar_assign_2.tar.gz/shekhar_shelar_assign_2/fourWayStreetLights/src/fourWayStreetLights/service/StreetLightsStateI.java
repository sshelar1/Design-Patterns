package fourWayStreetLights.service;

import fourWayStreetLights.util.FourWayStreetLights;

public interface StreetLightsStateI {
	public FourWayStreetLights passTraffic(FourWayStreetLights fourWayStreetLights,  String line);
}
