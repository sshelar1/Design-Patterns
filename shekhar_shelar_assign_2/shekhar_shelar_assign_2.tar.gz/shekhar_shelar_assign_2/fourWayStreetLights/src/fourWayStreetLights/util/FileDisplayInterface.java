package fourWayStreetLights.util;

public interface FileDisplayInterface {
	public void writeToFile(String s);
}
