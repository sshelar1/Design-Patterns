package studentCoursesBackup.util;

public interface FileDisplayInterface {
	public void writeToFile();
}
