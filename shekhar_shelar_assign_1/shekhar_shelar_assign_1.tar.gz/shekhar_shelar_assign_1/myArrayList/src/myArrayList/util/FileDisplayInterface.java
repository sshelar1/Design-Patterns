package myArrayList.util;

public interface FileDisplayInterface {
	public void writeToFile(String s);
}
