package myArrayList.util;

public class Logger {

}
